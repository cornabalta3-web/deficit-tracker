# Déficit Tracker — Despliegue en Netlify

## Qué incluye esta carpeta
- `index.html` — la app completa (frontend), sin dependencias externas.
- `netlify/functions/analyze.js` — función serverless que llama a la API de Anthropic protegiendo tu clave.
- `netlify.toml` — configuración de Netlify.

**Importante**: el método de "arrastrar y soltar" (Netlify Drop) NO soporta funciones serverless, solo sitios estáticos simples. Como esta app necesita la función que protege tu clave de API, hay que usar el método de GitHub + Netlify (los pasos de abajo). Es gratis y no hace falta saber programar.

## Paso 1 — Conseguir tu clave de API de Anthropic
1. Andá a https://console.anthropic.com
2. Creá una cuenta (o iniciá sesión) y cargá una tarjeta / créditos de facturación.
3. Andá a **Settings > API Keys** y creá una nueva clave.
4. Copiala — la vas a necesitar en el Paso 4. **No la compartas ni la pegues en el código del frontend.**

## Paso 2 — Subir el proyecto a GitHub
1. Creá una cuenta gratis en https://github.com (si no tenés una).
2. Tocá el botón verde **"New"** (o el "+" arriba a la derecha → "New repository").
3. Ponele un nombre, por ejemplo `deficit-tracker`. Dejalo en "Public" o "Private", como prefieras. NO marques ninguna opción de agregar README (ya tenemos uno). Creá el repositorio.
4. En la página del repo vacío, tocá **"uploading an existing file"** (o "Add file" → "Upload files").
5. Arrastrá o seleccioná `index.html`, `netlify.toml` y `README.md` — subilos así, sueltos.
6. Para el archivo de la función, que necesita quedar en una subcarpeta: tocá **"Add file" → "Create new file"**. En el campo de nombre, escribí exactamente:
   `netlify/functions/analyze.js`
   (al escribir las barras "/", GitHub crea las carpetas solo). Pegá adentro todo el contenido de `analyze.js`.
7. Tocá **"Commit changes"** para guardar.

## Paso 3 — Conectar el repositorio a Netlify
1. Andá a https://app.netlify.com y creá una cuenta gratis (podés usar tu cuenta de GitHub para entrar, es más rápido).
2. Tocá **"Add new site"** → **"Import an existing project"**.
3. Elegí **GitHub**, autorizá el acceso, y seleccioná el repositorio `deficit-tracker` que creaste.
4. Dejá la configuración por defecto (Netlify va a detectar la carpeta de funciones sola gracias al `netlify.toml`) y tocá **"Deploy"**.
5. Esperá un minuto — te va a dar una URL tipo `https://algo-random.netlify.app`.

## Paso 4 — Configurar tu clave de forma segura
1. En el dashboard de Netlify, entrá al sitio que acabás de crear.
2. Andá a **Site configuration > Environment variables**.
3. Agregá una variable nueva:
   - Key: `ANTHROPIC_API_KEY`
   - Value: (pegá la clave que copiaste en el Paso 1)
4. Guardá. Después andá a la pestaña **"Deploys"** y tocá **"Trigger deploy" → "Deploy site"** para que la variable tome efecto.

## Paso 5 — Agregarlo a tu iPhone
1. Abrí la URL de Netlify en Safari.
2. Confirmá que carga bien (deberías ver la pantalla de "Contame sobre vos").
3. Ícono de compartir → "Agregar a pantalla de inicio" → activá "Abrir como app web".
4. Como ahora es tu propio dominio (no claude.ai), no debería haber problemas de redirección a ninguna app.

## Cómo actualizar la app en el futuro
Si en el futuro querés que le agregue o cambie algo, yo te doy el código nuevo, y vos:
1. Entrás al archivo correspondiente en GitHub (por ejemplo `index.html`).
2. Tocás el ícono de lápiz (editar) arriba a la derecha del archivo.
3. Borrás todo y pegás el contenido nuevo.
4. "Commit changes".
Netlify redespliega solo automáticamente en unos segundos cada vez que hay un cambio en GitHub.

## Nota sobre costos
Cada análisis de comida cuesta una fracción de centavo de dólar (ver cálculo que hicimos en el chat). Para uso personal, esperá gastar menos de $2-3 dólares por mes en la API.

## Nota sobre los datos
Esta versión usa `localStorage` del navegador — tus datos quedan guardados en ese dispositivo/navegador específico. Si cambiás de celular o borrás datos de Safari, se pierde el historial. Usá el botón de "Descargar respaldo" dentro de la app periódicamente para tener una copia de seguridad en un archivo aparte.

